Comandos no Menu: W,A,S,D,ENTER
Comandos no Jogo: Q,W,E,A,D,J,K,L

ARQUIVO PRINCIPAL : jogo.s

Inicializar na main