package net.saga.game.cloclo.characters.obstacle;

/**
 * Characteristics of objects
 */
public enum Characteristic {
    PASSABLE,//Allows a character to pass through it
    PUSHABLE//Allows a character to move it
}
