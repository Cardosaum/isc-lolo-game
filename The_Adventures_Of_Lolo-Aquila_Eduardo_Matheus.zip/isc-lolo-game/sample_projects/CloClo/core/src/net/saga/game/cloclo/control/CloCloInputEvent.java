package net.saga.game.cloclo.control;

public enum CloCloInputEvent {
    UP,DOWN,LEFT,RIGHT, ACTION, CENTER, BACK, TAB
}
