package net.saga.game.cloclo.characters.obstacle;

public abstract class EnemyActor extends Obstacle {
}
